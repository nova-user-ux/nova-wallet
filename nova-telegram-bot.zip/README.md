# NOVA Telegram Bot

Telegram-бот NOVA Wallet на Python + aiogram.

## Запуск в Codespaces

```bash
pip install -r requirements.txt
export BOT_TOKEN="ТВОЙ_ТОКЕН_ОТ_BOTFATHER"
python bot.py
```

Не публикуй токен в GitHub.
