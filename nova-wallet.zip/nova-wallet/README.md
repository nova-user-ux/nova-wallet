# NOVA Wallet

NOVA Wallet is a production-oriented Next.js/TypeScript starter for a digital ecosystem combining Messenger, Marketplace, Gifts, Usernames, Numbers, Collectibles, Stars and a mock Wallet.

> **Demo economy only.** No real money, SMS, external wallet, or Telegram username transfer is connected.

## Stack

- Next.js 15 + React 19 + TypeScript
- Tailwind-ready architecture (the demo shell uses a focused CSS design system)
- PostgreSQL + Prisma
- Server-side owner session using an httpOnly signed cookie
- Zod validation and server-side balance mutations
- Mock API boundaries ready for real providers

## Run

1. `cp .env.example .env`
2. Set `DATABASE_URL`, `OWNER_PASSWORD`, and a long `SESSION_SECRET`.
3. `npm install`
4. `npm run db:generate`
5. `npm run db:push`
6. `npm run db:seed`
7. `npm run dev`
8. Open `/` and `/nova-panel/login`.

## Owner security

`OWNER_PASSWORD` is read only on the server. It is never placed in frontend code. The Nova Panel route checks the signed owner session server-side, and the Stars mutation checks the same authorization before running a Prisma transaction.

For production: hash/rotate the secret in a secrets manager, use a real session store, add CSRF protection appropriate to the chosen auth flow, rate-limit auth and economy endpoints, add WebSocket authentication, object storage with signed URLs, observability, backups, and a payment provider adapter.

## Architecture notes

The Prisma schema contains the requested core entities and relationships. Marketplace checkout follows `Buyer -> Order -> Transaction -> Wallet`, with fee calculation and balance deduction inside a database transaction. P2P escrow can be represented by `Wallet.pending` plus an order/dispute state machine.

The UI intentionally avoids Telegram's exact UI, logo, typography, or visual identity. NOVA uses its own neon-violet/cyan system, Space Grotesk headings, compact cards, and a distinct N prism mark.

## Demo accounts

The seeded database creates `alex` plus `user2` … `user24`, each with 5,000 Stars. Mock OTP returns `123456` during development.

## Core API examples

- `POST /api/auth/otp` — mock OTP request
- `POST /api/auth/logout` — clear owner session cookie
- `POST /api/marketplace/buy` — transactional mock purchase
- `POST /api/owner/login` — server-side owner authentication
- `POST /api/owner/stars` — OWNER-only Stars adjustment with DB transaction
