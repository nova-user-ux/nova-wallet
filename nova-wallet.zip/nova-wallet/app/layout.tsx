import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "NOVA — Your digital world. One wallet.",
  description: "NOVA Wallet demo digital ecosystem"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
