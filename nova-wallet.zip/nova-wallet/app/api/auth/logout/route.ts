import {NextResponse} from 'next/server';import {clearOwnerSession} from '@/lib/security';export async function POST(){await clearOwnerSession();return NextResponse.json({ok:true});}
