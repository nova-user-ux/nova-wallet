import {NextResponse} from 'next/server';import {z} from 'zod';
export async function POST(req:Request){const parsed=z.object({phone:z.string().min(4)}).safeParse(await req.json());if(!parsed.success)return NextResponse.json({error:'Invalid phone'},{status:400});return NextResponse.json({ok:true,demoCode:'123456',message:'Mock OTP issued. Production should use a trusted provider.'});}
