export type User={id:string;name:string;username:string;avatar:string;online:boolean;stars:number};
export type Product={id:string;type:string;name:string;icon:string;rarity?:string;price:number;seller:string;status:string};
export const users:User[]=[
{id:'u1',name:'Alex Morgan',username:'alex',avatar:'AM',online:true,stars:5000},{id:'u2',name:'Nora Vale',username:'nova',avatar:'NV',online:true,stars:12400},{id:'u3',name:'Mika Chen',username:'mika',avatar:'MC',online:false,stars:7800},{id:'u4',name:'Theo Park',username:'theo',avatar:'TP',online:true,stars:3200},{id:'u5',name:'Lena Stone',username:'lena',avatar:'LS',online:false,stars:9100}
];
export const chats=[{id:'c1',user:'Nora Vale',username:'nova',avatar:'NV',last:'The collectible looks unreal ✨',time:'00:48',unread:3},{id:'c2',user:'Mika Chen',username:'mika',avatar:'MC',last:'Want to list it on NOVA?',time:'23:31',unread:0},{id:'c3',user:'NOVA Creators',username:'creators',avatar:'NC',last:'New drops are live.',time:'Yesterday',unread:12},{id:'c4',user:'Theo Park',username:'theo',avatar:'TP',last:'Thanks for the gift!',time:'Mon',unread:0}];
export const products:Product[]=[
{id:'g1',type:'Gift',name:'Orbit Bloom',icon:'🌌',rarity:'Legendary',price:1200,seller:'NOVA Studio',status:'Available'},
{id:'g2',type:'Gift',name:'Pixel Fox',icon:'🦊',rarity:'Epic',price:650,seller:'nova',status:'Available'},
{id:'g3',type:'Gift',name:'Lunar Tea',icon:'🫖',rarity:'Rare',price:320,seller:'alex',status:'Available'},
{id:'u1',type:'Username',name:'@crypto',icon:'@',price:24000,seller:'nova',status:'Listed'},
{id:'u2',type:'Username',name:'@music',icon:'♫',price:8400,seller:'mika',status:'Listed'},
{id:'n1',type:'Number',name:'+1 *** *** 1234',icon:'📱',price:900,seller:'NOVA Numbers',status:'Test'},
{id:'c1',type:'Collectible',name:'Nova Shard #041',icon:'💎',rarity:'Mythic',price:18500,seller:'theo',status:'Listed'},
{id:'c2',type:'Collectible',name:'Aurora Frame #18',icon:'🪐',rarity:'Epic',price:5200,seller:'lena',status:'Listed'},
];
export const transactions=[{id:'TX-1042',kind:'Gift purchase',amount:-1200,status:'Completed',date:'Sep 07, 2026'},{id:'TX-1038',kind:'Stars top-up',amount:5000,status:'Completed',date:'Sep 06, 2026'},{id:'TX-1027',kind:'Marketplace sale',amount:8400,status:'Completed',date:'Sep 05, 2026'},{id:'TX-1019',kind:'Escrow reservation',amount:-5200,status:'Pending',date:'Sep 04, 2026'}];
