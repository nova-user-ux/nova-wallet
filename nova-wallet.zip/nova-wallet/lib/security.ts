import {cookies,headers} from 'next/headers';
import {createHash,randomBytes} from 'crypto';
import {jwtVerify,SignJWT} from 'jose';
import {prisma} from './prisma';
const secret=new TextEncoder().encode(process.env.SESSION_SECRET||'dev-only-secret-change-me');
export async function createOwnerSession(){const token=await new SignJWT({role:'OWNER'}).setProtectedHeader({alg:'HS256'}).setExpirationTime('8h').setIssuedAt().sign(secret);(await cookies()).set('nova_owner',token,{httpOnly:true,secure:process.env.NODE_ENV==='production',sameSite:'lax',path:'/',maxAge:60*60*8});}
export async function requireOwner(){const token=(await cookies()).get('nova_owner')?.value;if(!token) return false;try{const {payload}=await jwtVerify(token,secret);return payload.role==='OWNER';}catch{return false}}
export async function clearOwnerSession(){(await cookies()).delete('nova_owner')}
export async function ownerAudit(action:string,targetUserId:string|undefined,amount:number|undefined,reason:string,result='SUCCESS'){if(!await requireOwner()) throw new Error('FORBIDDEN');const h=await headers();return prisma.auditLog.create({data:{ownerId:'owner-system',action,targetUserId,amount,reason,result,ip:h.get('x-forwarded-for')||undefined,device:h.get('user-agent')||undefined}})}
export function hashToken(token:string){return createHash('sha256').update(token).digest('hex')}
export function newToken(){return randomBytes(32).toString('hex')}
